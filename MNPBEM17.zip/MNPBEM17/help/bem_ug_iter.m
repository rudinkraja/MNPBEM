%% Iterative BEM solvers
%
% * <bem_ug_bemiter.html Simulations with iterative BEM solvers>
% * <bem_ug_clustertree.html Cluster tree>
% * <bem_ug_hmatrix.html Hierarchical matrices>
%
% Copyright 2017 Ulrich Hohenester