%% Layer structure
%
% * <bem_ug_layerstructure.html The layerstructure class>
% * <bem_ug_layergreen.html Tabulated Green functions>
% * <bem_ug_layersim.html Simulations with layer structures>
%
% Copyright 2017 Ulrich Hohenester