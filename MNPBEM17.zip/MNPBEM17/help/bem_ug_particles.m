%% Particles
%
% * <bem_ug_particle.html The particle class>
% * <bem_ug_particleshapes.html Elementary particle shapes>
% * <bem_ug_polygon.html The polygon class>
% * <bem_ug_edgeprofile.html The edgeprofile class>
% * <bem_ug_polygon3.html The polygon3 class>
% * <bem_ug_integration.html Particle integration>
%
%%
% Copyright 2017 Ulrich Hohenester