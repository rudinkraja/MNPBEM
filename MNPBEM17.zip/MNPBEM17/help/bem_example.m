%% MNPBEM Examples
%
% * <bem_example1.html Planewave excitation examples>
% * <bem_example2.html Dipole excitation examples>
% * <bem_example3.html EELS simulation examples>
%
% Copyright 2017 Ulrich Hohenester