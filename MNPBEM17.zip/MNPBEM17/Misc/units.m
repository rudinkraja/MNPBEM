%  UNITS - conversion between eV and nm
eV2nm = 1 / 8.0655477e-4;